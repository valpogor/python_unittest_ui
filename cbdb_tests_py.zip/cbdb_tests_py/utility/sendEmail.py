import smtplib
import ssl
import unittest
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

subject = "Report"
body = "Please find attached report"
receiver_email = "vsp015@gmail.com"
sender_email = "vsp015@gmail.com"
password = "your password"
smtp_server = "smtp.gmail.com"
port = 587
port2 = 465
context = ssl.create_default_context()


def sendAttachmentEmail(filename):
    message = MIMEMultipart()
    message["From"] = sender_email
    message["To"] = receiver_email
    message["Subject"] = subject
    message["Bcc"] = receiver_email
    message.attach(MIMEText(body, "plain"))
    with smtplib.SMTP_SSL("smtp.gmail.com", port2) as server:
        server.login(sender_email, password)
        server.sendmail(sender_email, receiver_email, filename)


def sendEmail(m):
    msg = MIMEMultipart('alternative')
    msg['Subject'] = "Report"
    msg['From'] = sender_email
    msg['To'] = receiver_email
    part2 = MIMEMultipart(m, 'txt')
    msg.attach(part2)
    s = smtplib.SMTP_SSL('smtp.gmail.com')
    s.login(sender_email, password)
    s.sendmail(sender_email, receiver_email, msg.as_bytes())
    s.quit()


if __name__ == "__main__":
    unittest.main()
